Run the setup.exe file
and then find the application on your computer and run it.